import mongoose from 'mongoose';


// Database model

const modelSchema = mongoose.Schema({
    text: {type: String, required: true}
});

const Model = mongoose.model('Model', modelSchema);


// Database utils

export function setUpConnection() {
    mongoose.connect(`mongodb://localhost/models`);
}

export function listModels(id) {
    return Model.find();
}

export function createModel(data) {
    const model = new Model({
        text: data.text
    });

    return model.save();
}

export function deleteModel(id) {
    return Model.findById(id).remove();
}