import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import * as db from './dbUtils';

const app = express();

db.setUpConnection();

app.use(bodyParser.json());
app.use(cors({origin: '*'}));

app.get('/models', (req, res) => {
    db.listModels().then(data => {res.send(data)});
});

app.post('/models', (req, res) => {
    db.createModel(req.body).then(data => {res.send(data)});
});

app.delete('/models/:id', (req, res) => {
    db.deleteModel(req.params.id).then(data => {res.send(data)});
});

const server = app.listen(8080, ()=> {
    console.log('server is up and running on port 8080')
});