var actions = {
    LOAD_TASK_REQUEST: 'LOAD_TASK_REQUEST',
    LOAD_TASK_SUCCESS: 'LOAD_TASK_SUCCESS',
    LOAD_TASK_FAIL: 'LOAD_TASK_FAIL'
};

export default actions;