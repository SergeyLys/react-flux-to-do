import React from 'react';
import Task from './Task';

class List extends React.Component {
    render() {
        return (
            <div className="task-list">
                {
                    this.props.tasks.map((task) => {
                        <Task key={task.id} onDelete={this.props.onListDelete.bind(null, task)}>
                            {task.text}
                        </Task>
                    })
                }
            </div>
        )
    }
}

export default List;

