import React from 'react';

class Task extends React.Component {

    componentWillMount() {
        console.log('will mount')
    }

    componentWillReceiveProps(nexprops) {
        console.log(nexprops);
    }

    render() {
        return (
            <div className='Task'>
                <span className='Task__del-icon' onClick={this.props.onDelete}> × </span>
                <div className='Task__text'>{this.props.children}</div>
            </div>
        );
    }
}

export default Task;