import React from 'react';

class ListEditor extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            text: ''
        }
    }

    handleTextChange(event) {
        this.setState({
            text: event.target.value
        })
    }

    handleListAdd() {
        const newText = {
            text: this.state.text
        };

        this.props.onListAdd(newText);
        this.setState({text: ''});
    }

    render() {
        return (
            <div className="task-editor">
                <input type="text" placeholder="Enter text" value={this.state.text} onChange={this.handleTextChange.bind(this)}/>
                <button onClick={this.handleListAdd.bind(this)}>Add</button>
            </div>
        )
    }
}

export default ListEditor;