import React from 'react';
import ReactDOM from 'react-dom';

import TasksStore from './stores/listStore';
import ListActions from './actions/actions';

import Task from './components/Task';
import ListEditor from './components/ListEditor';
import List from './components/List';
import './main.scss';

function getStateFromFlux() {
    return {
        isLoading: TasksStore.isLoading(),
        tasks: TasksStore.getTasks()
    }
}

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = getStateFromFlux();
    }

    componentWillMount() {
        ListActions.loadList();
    }

    componentDidMount() {
        TasksStore.addChangeListener(this.onChange.bind(this));
    }

    componentWillUnmount() {
        TasksStore.removeChangeListener(this.onChange.bind(this))
    }

    handleListAdd(data) {
        ListActions.createTask(data);
    }

    handleListDelete(task) {
        ListActions.deleteTask(task.id);
    }

    onChange() {
        this.setState(getStateFromFlux());
    }

    render() {
        return (
            <div>
                <ListEditor onListAdd={this.handleListAdd.bind(this)} />
                <List tasks={this.state.tasks} onListDelete={this.handleListDelete.bind(this)} />
            </div>
        )
    }
}

ReactDOM.render(
    <App />,
    document.getElementById('app')
);